# CrimeWatchID (Flutter)

A simple Flutter app that lists *INTERPOL Red Notices* for **Indonesian nationals** (WNI). 
Intended as a starting point; extend with more official sources as they become available.

> Data source: Public Interpol Red Notices API proxy (`/notices/v1/red?nationality=ID`).

## Build steps (Android APK)
1. Ensure Flutter SDK is installed and `flutter doctor` shows no issues.
2. Extract this project ZIP, then open a terminal in the project folder.
3. Run:
   ```bash
   flutter pub get
   flutter build apk --release
   ```
4. The APK will be at: `build/app/outputs/flutter-apk/app-release.apk`.

## Notes
- This app polls Interpol every 15 minutes when open; you can also pull-to-refresh.
- Add more feeds later (e.g., Humas Polri news RSS) in `services/`.
- For push notifications (background alerts), integrate Firebase Cloud Messaging later.

