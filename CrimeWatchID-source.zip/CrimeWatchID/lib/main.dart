import 'dart:async';
import 'package:flutter/material.dart';
import 'services/interpol_service.dart';
import 'models/red_notice.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  runApp(const CrimeWatchApp());
}

class CrimeWatchApp extends StatelessWidget {
  const CrimeWatchApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CrimeWatchID',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.indigo,
      ),
      home: const NoticeListPage(),
    );
  }
}

class NoticeListPage extends StatefulWidget {
  const NoticeListPage({super.key});
  @override
  State<NoticeListPage> createState() => _NoticeListPageState();
}

class _NoticeListPageState extends State<NoticeListPage> {
  final _service = InterpolService();
  final _controller = ScrollController();
  final _searchCtrl = TextEditingController();
  List<RedNotice> _items = [];
  bool _loading = false;
  String _error = '';
  Timer? _pollTimer;

  @override
  void initState() {
    super.initState();
    _load();
    // Poll every 15 minutes while the app is open
    _pollTimer = Timer.periodic(const Duration(minutes: 15), (_) => _load());
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _controller.dispose();
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _load({String query = ''}) async {
    setState(() { _loading = true; _error = ''; });
    try {
      final data = await _service.fetchNotices(nationality: 'ID', nameQuery: query);
      setState(() { _items = data; });
    } catch (e) {
      setState(() { _error = e.toString(); });
    } finally {
      setState(() { _loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('CrimeWatchID – Interpol Red Notices (WNI)'),
        actions: [
          IconButton(
            onPressed: () => _load(query: _searchCtrl.text.trim()),
            icon: const Icon(Icons.refresh),
            tooltip: 'Refresh',
          )
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _searchCtrl,
                    decoration: const InputDecoration(
                      labelText: 'Cari nama (opsional)',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.search),
                    ),
                    onSubmitted: (v) => _load(query: v.trim()),
                  ),
                ),
                const SizedBox(width: 12),
                FilledButton.icon(
                  onPressed: () => _load(query: _searchCtrl.text.trim()),
                  icon: const Icon(Icons.search),
                  label: const Text('Cari'),
                )
              ],
            ),
          ),
          if (_loading) const LinearProgressIndicator(),
          if (_error.isNotEmpty)
            Padding(
              padding: const EdgeInsets.all(12),
              child: Text('Error: $_error', style: const TextStyle(color: Colors.red)),
            ),
          Expanded(
            child: RefreshIndicator(
              onRefresh: () => _load(query: _searchCtrl.text.trim()),
              child: ListView.separated(
                controller: _controller,
                itemCount: _items.length,
                separatorBuilder: (_, __) => const Divider(height: 0),
                itemBuilder: (context, index) {
                  final n = _items[index];
                  return ListTile(
                    leading: CircleAvatar(child: Text(n.initials)),
                    title: Text(n.fullName),
                    subtitle: Text(n.summaryLine),
                    trailing: const Icon(Icons.open_in_new),
                    onTap: () async {
                      final url = n.detailUrl ?? n.selfUrl;
                      if (url != null && await canLaunchUrl(Uri.parse(url))) {
                        await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
                      }
                    },
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
