class RedNotice {
  final String? name;
  final String? forename;
  final String? dateOfBirth;
  final List<dynamic>? nationalities;
  final String? charge;
  final String? selfUrl;
  final String? detailUrl;

  RedNotice({
    this.name,
    this.forename,
    this.dateOfBirth,
    this.nationalities,
    this.charge,
    this.selfUrl,
    this.detailUrl,
  });

  factory RedNotice.fromJson(Map<String, dynamic> json) {
    String? charge;
    if (json['arrest_warrants'] is List && (json['arrest_warrants'] as List).isNotEmpty) {
      final aw = (json['arrest_warrants'] as List).first;
      if (aw is Map && aw['charge'] is String) {
        charge = aw['charge'] as String;
      }
    }
    String? selfUrl;
    String? detailUrl;
    if (json['_links'] is Map) {
      final links = json['_links'] as Map;
      if (links['self'] is Map) selfUrl = (links['self'] as Map)['href'] as String?;
      if (links['images'] is Map) detailUrl = (links['images'] as Map)['href'] as String?;
    }
    return RedNotice(
      name: json['name'] as String?,
      forename: json['forename'] as String?,
      dateOfBirth: json['date_of_birth'] as String?,
      nationalities: json['nationalities'] as List<dynamic>?,
      charge: charge,
      selfUrl: selfUrl,
      detailUrl: detailUrl,
    );
  }

  String get fullName {
    final parts = [forename, name].where((e) => (e ?? '').trim().isNotEmpty).toList();
    return parts.isNotEmpty ? parts.join(' ') : 'Nama tidak tersedia';
    }

  String get initials {
    final fn = fullName.trim();
    if (fn.isEmpty) return '?';
    final segs = fn.split(RegExp(r'\s+'));
    final letters = segs.take(2).map((s) => s.isNotEmpty ? s[0] : '').join();
    return letters.toUpperCase();
  }

  String get summaryLine {
    final dob = dateOfBirth != null ? 'Lahir: $dateOfBirth' : 'Tanggal lahir tidak tersedia';
    final nat = (nationalities != null && nationalities!.isNotEmpty) ? '• WN ${nationalities!.join(", ")}' : '';
    final chg = (charge != null && charge!.trim().isNotEmpty) ? '• Dugaan: $charge' : '';
    return [dob, nat, chg].where((e) => e.isNotEmpty).join('  ');
  }
}
