import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/red_notice.dart';

class InterpolService {
  static const String base = 'https://interpol.api.bund.dev';

  Future<List<RedNotice>> fetchNotices({String nationality = 'ID', String nameQuery = ''}) async {
    final params = {
      'nationality': nationality,
      'resultPerPage': '50',
      if (nameQuery.isNotEmpty) 'name': nameQuery,
    };
    final uri = Uri.parse('$base/notices/v1/red').replace(queryParameters: params);
    final res = await http.get(uri, headers: {
      'Accept': 'application/json',
      'User-Agent': 'CrimeWatchID/1.0 (+github.com/example)',
    });
    if (res.statusCode != 200) {
      throw Exception('HTTP ${res.statusCode}: ${res.body}');
    }
    final data = json.decode(res.body);
    final embedded = data['_embedded'];
    final notices = embedded != null ? embedded['notices'] as List<dynamic>? : null;
    if (notices == null) return [];
    return notices.map((e) => RedNotice.fromJson(e as Map<String, dynamic>)).toList();
  }
}
